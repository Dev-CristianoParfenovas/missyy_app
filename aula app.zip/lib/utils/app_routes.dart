class AppRoutes {
  static const productDetail = '/product-detail';
  static const cart = '/cart';
}
